﻿namespace Software_de_Inventario
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            panel1 = new Panel();
            btn_login = new Button();
            checkBox = new CheckBox();
            textBox_contraseña = new TextBox();
            label2 = new Label();
            textBox_usuario = new TextBox();
            label1 = new Label();
            pictureBox1 = new PictureBox();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Controls.Add(btn_login);
            panel1.Controls.Add(checkBox);
            panel1.Controls.Add(textBox_contraseña);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(textBox_usuario);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(pictureBox1);
            panel1.Location = new Point(93, 46);
            panel1.Margin = new Padding(3, 2, 3, 2);
            panel1.Name = "panel1";
            panel1.Size = new Size(710, 420);
            panel1.TabIndex = 0;
            // 
            // btn_login
            // 
            btn_login.BackColor = Color.Black;
            btn_login.Cursor = Cursors.Hand;
            btn_login.FlatAppearance.BorderSize = 0;
            btn_login.FlatStyle = FlatStyle.Flat;
            btn_login.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btn_login.ForeColor = Color.White;
            btn_login.Location = new Point(422, 305);
            btn_login.Margin = new Padding(3, 2, 3, 2);
            btn_login.Name = "btn_login";
            btn_login.Size = new Size(147, 42);
            btn_login.TabIndex = 6;
            btn_login.Text = "Iniciar Sesión";
            btn_login.UseVisualStyleBackColor = false;
            btn_login.Click += btn_login_Click;
            // 
            // checkBox
            // 
            checkBox.Appearance = Appearance.Button;
            checkBox.AutoSize = true;
            checkBox.BackColor = Color.Transparent;
            checkBox.BackgroundImageLayout = ImageLayout.Stretch;
            checkBox.Cursor = Cursors.Hand;
            checkBox.FlatAppearance.BorderSize = 0;
            checkBox.FlatAppearance.CheckedBackColor = Color.Transparent;
            checkBox.FlatAppearance.MouseDownBackColor = Color.Transparent;
            checkBox.FlatAppearance.MouseOverBackColor = Color.Transparent;
            checkBox.FlatStyle = FlatStyle.Flat;
            checkBox.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            checkBox.Image = Properties.Resources.nocheck1;
            checkBox.Location = new Point(399, 254);
            checkBox.Margin = new Padding(3, 2, 3, 2);
            checkBox.Name = "checkBox";
            checkBox.Size = new Size(179, 31);
            checkBox.TabIndex = 5;
            checkBox.Text = "Mostrar contraseña";
            checkBox.TextAlign = ContentAlignment.BottomCenter;
            checkBox.TextImageRelation = TextImageRelation.ImageBeforeText;
            checkBox.UseVisualStyleBackColor = false;
            checkBox.CheckedChanged += chkCheckedCh;
            // 
            // textBox_contraseña
            // 
            textBox_contraseña.Cursor = Cursors.IBeam;
            textBox_contraseña.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            textBox_contraseña.Location = new Point(399, 206);
            textBox_contraseña.Margin = new Padding(3, 2, 3, 2);
            textBox_contraseña.Multiline = true;
            textBox_contraseña.Name = "textBox_contraseña";
            textBox_contraseña.PasswordChar = '*';
            textBox_contraseña.Size = new Size(191, 34);
            textBox_contraseña.TabIndex = 4;
            textBox_contraseña.KeyPress += textBox_contraseña_KeyPress;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(419, 154);
            label2.Name = "label2";
            label2.Size = new Size(162, 37);
            label2.TabIndex = 3;
            label2.Text = "Contraseña";
            // 
            // textBox_usuario
            // 
            textBox_usuario.Cursor = Cursors.IBeam;
            textBox_usuario.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            textBox_usuario.Location = new Point(399, 95);
            textBox_usuario.Margin = new Padding(3, 2, 3, 2);
            textBox_usuario.Multiline = true;
            textBox_usuario.Name = "textBox_usuario";
            textBox_usuario.Size = new Size(191, 37);
            textBox_usuario.TabIndex = 2;
            textBox_usuario.KeyPress += textBox_usuario_KeyPress;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(445, 40);
            label1.Name = "label1";
            label1.Size = new Size(116, 37);
            label1.TabIndex = 1;
            label1.Text = "Usuario";
            // 
            // pictureBox1
            // 
            pictureBox1.BackgroundImage = (Image)resources.GetObject("pictureBox1.BackgroundImage");
            pictureBox1.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox1.Location = new Point(-1, -1);
            pictureBox1.Margin = new Padding(3, 2, 3, 2);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(287, 420);
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(919, 513);
            Controls.Add(panel1);
            Margin = new Padding(3, 2, 3, 2);
            Name = "Form1";
            Text = "Form1";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private TextBox textBox_usuario;
        private Label label1;
        private PictureBox pictureBox1;
        private CheckBox checkBox;
        private TextBox textBox_contraseña;
        private Label label2;
        private Button btn_login;
    }
}