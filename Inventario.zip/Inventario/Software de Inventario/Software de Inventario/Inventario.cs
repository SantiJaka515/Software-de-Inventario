﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Software_de_Inventario
{
    public partial class Inventario : Form
    {
        MySqlConnection conexion = new MySqlConnection("server=localhost; database=tienda; Uid=root; Pwd=;");

        public Inventario()
        {
            InitializeComponent();
        }

        private void menu_Click(object sender, EventArgs e)
        {
            menu.Visible = false;
            logo1.Visible = false;
            label1.Visible = false;
            tablaInvnetario.Visible = false;
            groupBox1.Visible = false;
            textBox_buscar.Visible = false;


            closeMenu.Visible = true;
            barraLateral.Visible = true;
        }

        private void Inventario_Load(object sender, EventArgs e)
        {
            conexion.Open();

            string consulta = "SELECT inventario.producto AS Producto, inventario.cantidad AS Stock, inventario.precio AS Precio, proveedor.nombre AS Proveedor, marca.nombre AS Marca FROM inventario INNER JOIN proveedor ON proveedor.idproveedor = inventario.idproveedor INNER JOIN marca ON marca.idmarca = inventario.idmarca";
            MySqlDataAdapter adaptador = new MySqlDataAdapter(consulta, conexion);
            DataTable dt = new DataTable();
            adaptador.Fill(dt);
            tablaInvnetario.DataSource = dt;

            conexion.Close();
        }

        private void closeMenu_Click(object sender, EventArgs e)
        {
            menu.Visible = true;
            logo1.Visible = true;
            label1.Visible = true;
            tablaInvnetario.Visible = true;

            closeMenu.Visible = false;
            barraLateral.Visible = false;
        }

        private void btnSeparados_Click(object sender, EventArgs e)
        {
            Separados newForm = new Separados();
            newForm.Show();
            this.Hide();
        }

        private void tablaInvnetario_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void textBox_buscar_Enter(object sender, EventArgs e)
        {
            if (textBox_buscar.Text == "Buscar...")
            {
                textBox_buscar.Text = "";
                textBox_buscar.ForeColor = Color.Black;
                buscar.Visible = true;
            }
        }

        private void textBox_buscar_Leave(object sender, EventArgs e)
        {
            if (textBox_buscar.Text == "")
            {
                textBox_buscar.Text = "Buscar...";
                textBox_buscar.ForeColor = Color.Black;
                buscar.Visible = true;
            }
        }
    }
}
