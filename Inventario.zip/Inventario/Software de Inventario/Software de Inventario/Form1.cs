namespace Software_de_Inventario
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            MessageBox.Show("�Bienvenido!");

            Inventario newForm = new Inventario();
            newForm.Show();
            this.Hide();
        }

        private void chkCheckedCh(object sender, EventArgs e)
        {

            CheckBox chk = sender as CheckBox;
            if (chk.Checked)
            {
                chk.Image = Properties.Resources.check;
                textBox_contrase�a.UseSystemPasswordChar = true;
            }
            else
            {
                chk.Image = Properties.Resources.nocheck;
                textBox_contrase�a.UseSystemPasswordChar = false;
            }
        }

        private void textBox_usuario_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                textBox_contrase�a.Focus();
            }
        }

        private void textBox_contrase�a_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                btn_login_Click(sender, e);
            }
        }
    }
}