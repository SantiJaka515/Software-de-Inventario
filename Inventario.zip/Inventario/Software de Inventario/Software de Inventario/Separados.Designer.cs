﻿namespace Software_de_Inventario
{
    partial class Separados
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            nav = new Panel();
            closeMenu = new Button();
            label1 = new Label();
            logo1 = new Button();
            menu = new Button();
            barraLateral = new Panel();
            btnSeparados = new Button();
            btnInventario = new Button();
            label2 = new Label();
            logo2 = new Button();
            groupBox1 = new GroupBox();
            textBox_total = new TextBox();
            total = new Label();
            btn_insertar = new Button();
            btn_login = new Button();
            comboBox = new ComboBox();
            proveedor = new Label();
            textBox_fecha = new TextBox();
            fecha = new Label();
            textBox_descripcion = new TextBox();
            descripcion = new Label();
            textBox_cliente = new TextBox();
            cliente = new Label();
            timer1 = new System.Windows.Forms.Timer(components);
            tablaSeparados = new DataGridView();
            textBox_buscar = new TextBox();
            btn_buscar = new Button();
            buscar = new Label();
            nav.SuspendLayout();
            barraLateral.SuspendLayout();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)tablaSeparados).BeginInit();
            SuspendLayout();
            // 
            // nav
            // 
            nav.BackColor = Color.FromArgb(97, 210, 220);
            nav.Controls.Add(closeMenu);
            nav.Controls.Add(label1);
            nav.Controls.Add(logo1);
            nav.Controls.Add(menu);
            nav.Dock = DockStyle.Top;
            nav.Location = new Point(0, 0);
            nav.Margin = new Padding(3, 2, 3, 2);
            nav.Name = "nav";
            nav.Size = new Size(1163, 100);
            nav.TabIndex = 1;
            // 
            // closeMenu
            // 
            closeMenu.BackgroundImage = Properties.Resources.close;
            closeMenu.BackgroundImageLayout = ImageLayout.Zoom;
            closeMenu.Cursor = Cursors.Hand;
            closeMenu.FlatAppearance.BorderSize = 0;
            closeMenu.FlatAppearance.MouseDownBackColor = Color.Transparent;
            closeMenu.FlatAppearance.MouseOverBackColor = Color.Transparent;
            closeMenu.FlatStyle = FlatStyle.Flat;
            closeMenu.Location = new Point(24, 30);
            closeMenu.Margin = new Padding(3, 2, 3, 2);
            closeMenu.Name = "closeMenu";
            closeMenu.Size = new Size(59, 41);
            closeMenu.TabIndex = 3;
            closeMenu.UseVisualStyleBackColor = true;
            closeMenu.Visible = false;
            closeMenu.Click += closeMenu_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.White;
            label1.Location = new Point(916, 63);
            label1.Name = "label1";
            label1.Size = new Size(219, 21);
            label1.TabIndex = 2;
            label1.Text = "CREACIONES VALDERRAMA";
            // 
            // logo1
            // 
            logo1.BackgroundImage = Properties.Resources.logo;
            logo1.BackgroundImageLayout = ImageLayout.Zoom;
            logo1.FlatAppearance.BorderSize = 0;
            logo1.FlatAppearance.MouseDownBackColor = Color.Transparent;
            logo1.FlatAppearance.MouseOverBackColor = Color.Transparent;
            logo1.FlatStyle = FlatStyle.Flat;
            logo1.Location = new Point(931, -31);
            logo1.Margin = new Padding(3, 2, 3, 2);
            logo1.Name = "logo1";
            logo1.Size = new Size(194, 163);
            logo1.TabIndex = 1;
            logo1.UseVisualStyleBackColor = true;
            // 
            // menu
            // 
            menu.BackgroundImage = Properties.Resources.menu;
            menu.BackgroundImageLayout = ImageLayout.Zoom;
            menu.Cursor = Cursors.Hand;
            menu.FlatAppearance.BorderSize = 0;
            menu.FlatAppearance.MouseDownBackColor = Color.Transparent;
            menu.FlatAppearance.MouseOverBackColor = Color.Transparent;
            menu.FlatStyle = FlatStyle.Flat;
            menu.Location = new Point(24, 30);
            menu.Margin = new Padding(3, 2, 3, 2);
            menu.Name = "menu";
            menu.Size = new Size(59, 41);
            menu.TabIndex = 0;
            menu.UseVisualStyleBackColor = true;
            menu.Click += menu_Click;
            // 
            // barraLateral
            // 
            barraLateral.BackColor = Color.WhiteSmoke;
            barraLateral.Controls.Add(btnSeparados);
            barraLateral.Controls.Add(btnInventario);
            barraLateral.Controls.Add(label2);
            barraLateral.Controls.Add(logo2);
            barraLateral.Dock = DockStyle.Left;
            barraLateral.Location = new Point(0, 100);
            barraLateral.Margin = new Padding(3, 2, 3, 2);
            barraLateral.Name = "barraLateral";
            barraLateral.Size = new Size(295, 509);
            barraLateral.TabIndex = 2;
            barraLateral.Visible = false;
            // 
            // btnSeparados
            // 
            btnSeparados.Cursor = Cursors.Hand;
            btnSeparados.Enabled = false;
            btnSeparados.FlatAppearance.BorderSize = 0;
            btnSeparados.FlatStyle = FlatStyle.Flat;
            btnSeparados.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            btnSeparados.ForeColor = Color.FromArgb(74, 197, 199);
            btnSeparados.Location = new Point(0, 229);
            btnSeparados.Margin = new Padding(3, 2, 3, 2);
            btnSeparados.Name = "btnSeparados";
            btnSeparados.Size = new Size(295, 56);
            btnSeparados.TabIndex = 6;
            btnSeparados.Text = "SEPARADOS";
            btnSeparados.UseVisualStyleBackColor = true;
            // 
            // btnInventario
            // 
            btnInventario.FlatAppearance.BorderSize = 0;
            btnInventario.FlatStyle = FlatStyle.Flat;
            btnInventario.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            btnInventario.ForeColor = Color.FromArgb(74, 197, 199);
            btnInventario.Location = new Point(0, 169);
            btnInventario.Margin = new Padding(3, 2, 3, 2);
            btnInventario.Name = "btnInventario";
            btnInventario.Size = new Size(295, 56);
            btnInventario.TabIndex = 5;
            btnInventario.Text = "INVENTARIO";
            btnInventario.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label2.ForeColor = Color.FromArgb(74, 197, 199);
            label2.Location = new Point(24, 479);
            label2.Name = "label2";
            label2.Size = new Size(219, 21);
            label2.TabIndex = 4;
            label2.Text = "CREACIONES VALDERRAMA";
            // 
            // logo2
            // 
            logo2.BackgroundImage = Properties.Resources.logo2;
            logo2.BackgroundImageLayout = ImageLayout.Zoom;
            logo2.FlatAppearance.BorderSize = 0;
            logo2.FlatAppearance.MouseDownBackColor = Color.Transparent;
            logo2.FlatAppearance.MouseOverBackColor = Color.Transparent;
            logo2.FlatStyle = FlatStyle.Flat;
            logo2.Location = new Point(38, 358);
            logo2.Margin = new Padding(3, 2, 3, 2);
            logo2.Name = "logo2";
            logo2.Size = new Size(195, 214);
            logo2.TabIndex = 2;
            logo2.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(textBox_total);
            groupBox1.Controls.Add(total);
            groupBox1.Controls.Add(btn_insertar);
            groupBox1.Controls.Add(btn_login);
            groupBox1.Controls.Add(comboBox);
            groupBox1.Controls.Add(proveedor);
            groupBox1.Controls.Add(textBox_fecha);
            groupBox1.Controls.Add(fecha);
            groupBox1.Controls.Add(textBox_descripcion);
            groupBox1.Controls.Add(descripcion);
            groupBox1.Controls.Add(textBox_cliente);
            groupBox1.Controls.Add(cliente);
            groupBox1.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            groupBox1.Location = new Point(763, 137);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(372, 417);
            groupBox1.TabIndex = 3;
            groupBox1.TabStop = false;
            groupBox1.Text = "Insertar Datos";
            // 
            // textBox_total
            // 
            textBox_total.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            textBox_total.Location = new Point(106, 251);
            textBox_total.Multiline = true;
            textBox_total.Name = "textBox_total";
            textBox_total.Size = new Size(229, 28);
            textBox_total.TabIndex = 3;
            // 
            // total
            // 
            total.AutoSize = true;
            total.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            total.Location = new Point(18, 251);
            total.Name = "total";
            total.Size = new Size(56, 25);
            total.TabIndex = 10;
            total.Text = "Total:";
            // 
            // btn_insertar
            // 
            btn_insertar.BackColor = Color.FromArgb(0, 192, 192);
            btn_insertar.Cursor = Cursors.Hand;
            btn_insertar.FlatAppearance.BorderSize = 0;
            btn_insertar.FlatStyle = FlatStyle.Flat;
            btn_insertar.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btn_insertar.ForeColor = Color.White;
            btn_insertar.Location = new Point(106, 351);
            btn_insertar.Margin = new Padding(3, 2, 3, 2);
            btn_insertar.Name = "btn_insertar";
            btn_insertar.Size = new Size(102, 35);
            btn_insertar.TabIndex = 9;
            btn_insertar.Text = "Insertar";
            btn_insertar.UseVisualStyleBackColor = false;
            btn_insertar.Click += btn_insertar_Click;

            // 
            // btn_login
            // 
            btn_login.BackColor = Color.FromArgb(192, 0, 0);
            btn_login.Cursor = Cursors.Hand;
            btn_login.FlatAppearance.BorderSize = 0;
            btn_login.FlatStyle = FlatStyle.Flat;
            btn_login.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btn_login.ForeColor = Color.White;
            btn_login.Location = new Point(233, 351);
            btn_login.Margin = new Padding(3, 2, 3, 2);
            btn_login.Name = "btn_login";
            btn_login.Size = new Size(102, 35);
            btn_login.TabIndex = 8;
            btn_login.Text = "Limpiar";
            btn_login.UseVisualStyleBackColor = false;
            // 
            // comboBox
            // 
            comboBox.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            comboBox.FormattingEnabled = true;
            comboBox.Location = new Point(106, 296);
            comboBox.Name = "comboBox";
            comboBox.Size = new Size(229, 33);
            comboBox.TabIndex = 4;
            comboBox.Text = "----------------------------------";
            comboBox.SelectedIndexChanged += comboBox_SelectedIndexChanged;
            comboBox.Click += comboBox_Click;
            // 
            // proveedor
            // 
            proveedor.AutoSize = true;
            proveedor.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            proveedor.Location = new Point(-3, 299);
            proveedor.Name = "proveedor";
            proveedor.Size = new Size(103, 25);
            proveedor.TabIndex = 6;
            proveedor.Text = "Proveedor:";
            // 
            // textBox_fecha
            // 
            textBox_fecha.Enabled = false;
            textBox_fecha.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            textBox_fecha.Location = new Point(106, 208);
            textBox_fecha.Multiline = true;
            textBox_fecha.Name = "textBox_fecha";
            textBox_fecha.ReadOnly = true;
            textBox_fecha.Size = new Size(229, 28);
            textBox_fecha.TabIndex = 5;
            // 
            // fecha
            // 
            fecha.AutoSize = true;
            fecha.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            fecha.Location = new Point(18, 208);
            fecha.Name = "fecha";
            fecha.Size = new Size(65, 25);
            fecha.TabIndex = 4;
            fecha.Text = "Fecha:";
            // 
            // textBox_descripcion
            // 
            textBox_descripcion.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            textBox_descripcion.Location = new Point(121, 100);
            textBox_descripcion.Multiline = true;
            textBox_descripcion.Name = "textBox_descripcion";
            textBox_descripcion.Size = new Size(214, 88);
            textBox_descripcion.TabIndex = 2;
            // 
            // descripcion
            // 
            descripcion.AutoSize = true;
            descripcion.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            descripcion.Location = new Point(6, 100);
            descripcion.Name = "descripcion";
            descripcion.Size = new Size(115, 25);
            descripcion.TabIndex = 2;
            descripcion.Text = "Descripción:";
            // 
            // textBox_cliente
            // 
            textBox_cliente.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            textBox_cliente.Location = new Point(106, 55);
            textBox_cliente.Multiline = true;
            textBox_cliente.Name = "textBox_cliente";
            textBox_cliente.Size = new Size(229, 28);
            textBox_cliente.TabIndex = 1;
            // 
            // cliente
            // 
            cliente.AutoSize = true;
            cliente.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            cliente.Location = new Point(18, 55);
            cliente.Name = "cliente";
            cliente.Size = new Size(75, 25);
            cliente.TabIndex = 0;
            cliente.Text = "Cliente:";
            // 
            // timer1
            // 
            timer1.Tick += timer1_Tick;
            // 
            // tablaSeparados
            // 
            tablaSeparados.AllowUserToAddRows = false;
            tablaSeparados.AllowUserToDeleteRows = false;
            tablaSeparados.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            tablaSeparados.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            tablaSeparados.Location = new Point(38, 187);
            tablaSeparados.Name = "tablaSeparados";
            tablaSeparados.ReadOnly = true;
            tablaSeparados.RowTemplate.Height = 25;
            tablaSeparados.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            tablaSeparados.Size = new Size(716, 347);
            tablaSeparados.TabIndex = 4;
            // 
            // textBox_buscar
            // 
            textBox_buscar.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            textBox_buscar.ForeColor = Color.Silver;
            textBox_buscar.Location = new Point(310, 140);
            textBox_buscar.Multiline = true;
            textBox_buscar.Name = "textBox_buscar";
            textBox_buscar.Size = new Size(229, 28);
            textBox_buscar.TabIndex = 5;
            textBox_buscar.Text = "Buscar...";
            textBox_buscar.TextChanged += textBox_buscar_TextChanged;
            textBox_buscar.Enter += textBox_buscar_Enter;
            textBox_buscar.Leave += textBox_buscar_Leave;
            // 
            // btn_buscar
            // 
            btn_buscar.BackColor = Color.Black;
            btn_buscar.Cursor = Cursors.Hand;
            btn_buscar.FlatAppearance.BorderSize = 0;
            btn_buscar.FlatStyle = FlatStyle.Flat;
            btn_buscar.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btn_buscar.ForeColor = Color.White;
            btn_buscar.Location = new Point(634, 133);
            btn_buscar.Margin = new Padding(3, 2, 3, 2);
            btn_buscar.Name = "btn_buscar";
            btn_buscar.Size = new Size(107, 35);
            btn_buscar.TabIndex = 12;
            btn_buscar.Text = "Buscar";
            btn_buscar.UseVisualStyleBackColor = false;
            btn_buscar.Visible = false;
            btn_buscar.Click += btn_buscar_Click;
            // 
            // buscar
            // 
            buscar.AutoSize = true;
            buscar.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            buscar.Location = new Point(310, 111);
            buscar.Name = "buscar";
            buscar.Size = new Size(59, 21);
            buscar.TabIndex = 13;
            buscar.Text = "Buscar:";
            buscar.Visible = false;
            // 
            // Separados
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(209, 238, 234);
            ClientSize = new Size(1163, 609);
            Controls.Add(buscar);
            Controls.Add(btn_buscar);
            Controls.Add(textBox_buscar);
            Controls.Add(tablaSeparados);
            Controls.Add(groupBox1);
            Controls.Add(barraLateral);
            Controls.Add(nav);
            Name = "Separados";
            Text = "Separados";
            Load += Separados_Load;
            nav.ResumeLayout(false);
            nav.PerformLayout();
            barraLateral.ResumeLayout(false);
            barraLateral.PerformLayout();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)tablaSeparados).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel nav;
        private Button closeMenu;
        private Label label1;
        private Button logo1;
        private Button menu;
        private Panel barraLateral;
        private Button btnSeparados;
        private Button btnInventario;
        private Label label2;
        private Button logo2;
        private GroupBox groupBox1;
        private ComboBox comboBox;
        private Label proveedor;
        private TextBox textBox_fecha;
        private Label fecha;
        private TextBox textBox_descripcion;
        private Label descripcion;
        private TextBox textBox_cliente;
        private Label cliente;
        private Button btn_login;
        private Button btn_insertar;
        private TextBox textBox_total;
        private Label total;
        private System.Windows.Forms.Timer timer1;
        private DataGridView tablaSeparados;
        private TextBox textBox_buscar;
        private Button btn_buscar;
        private Label buscar;
    }
}