﻿namespace Software_de_Inventario
{
    partial class Inventario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            nav = new Panel();
            closeMenu = new Button();
            label1 = new Label();
            logo1 = new Button();
            menu = new Button();
            barraLateral = new Panel();
            btnSeparados = new Button();
            btnInventario = new Button();
            label2 = new Label();
            logo2 = new Button();
            tablaInvnetario = new DataGridView();
            groupBox1 = new GroupBox();
            comboBox_marca = new ComboBox();
            marca = new Label();
            textBox_precio = new TextBox();
            precio = new Label();
            btn_insertar = new Button();
            btn_login = new Button();
            comboBox_proveedor = new ComboBox();
            proveedor = new Label();
            textBox_fecha = new TextBox();
            fecha = new Label();
            textBox_cantidad = new TextBox();
            cantidad = new Label();
            textBox_producto = new TextBox();
            producto = new Label();
            buscar = new Label();
            textBox_buscar = new TextBox();
            nav.SuspendLayout();
            barraLateral.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)tablaInvnetario).BeginInit();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // nav
            // 
            nav.BackColor = Color.FromArgb(97, 210, 220);
            nav.Controls.Add(closeMenu);
            nav.Controls.Add(label1);
            nav.Controls.Add(logo1);
            nav.Controls.Add(menu);
            nav.Dock = DockStyle.Top;
            nav.Location = new Point(0, 0);
            nav.Margin = new Padding(3, 2, 3, 2);
            nav.Name = "nav";
            nav.Size = new Size(1163, 100);
            nav.TabIndex = 0;
            // 
            // closeMenu
            // 
            closeMenu.BackgroundImage = Properties.Resources.close;
            closeMenu.BackgroundImageLayout = ImageLayout.Zoom;
            closeMenu.Cursor = Cursors.Hand;
            closeMenu.FlatAppearance.BorderSize = 0;
            closeMenu.FlatAppearance.MouseDownBackColor = Color.Transparent;
            closeMenu.FlatAppearance.MouseOverBackColor = Color.Transparent;
            closeMenu.FlatStyle = FlatStyle.Flat;
            closeMenu.Location = new Point(24, 30);
            closeMenu.Margin = new Padding(3, 2, 3, 2);
            closeMenu.Name = "closeMenu";
            closeMenu.Size = new Size(59, 41);
            closeMenu.TabIndex = 3;
            closeMenu.UseVisualStyleBackColor = true;
            closeMenu.Visible = false;
            closeMenu.Click += closeMenu_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.White;
            label1.Location = new Point(916, 63);
            label1.Name = "label1";
            label1.Size = new Size(219, 21);
            label1.TabIndex = 2;
            label1.Text = "CREACIONES VALDERRAMA";
            // 
            // logo1
            // 
            logo1.BackgroundImage = Properties.Resources.logo;
            logo1.BackgroundImageLayout = ImageLayout.Zoom;
            logo1.FlatAppearance.BorderSize = 0;
            logo1.FlatAppearance.MouseDownBackColor = Color.Transparent;
            logo1.FlatAppearance.MouseOverBackColor = Color.Transparent;
            logo1.FlatStyle = FlatStyle.Flat;
            logo1.Location = new Point(931, -31);
            logo1.Margin = new Padding(3, 2, 3, 2);
            logo1.Name = "logo1";
            logo1.Size = new Size(194, 163);
            logo1.TabIndex = 1;
            logo1.UseVisualStyleBackColor = true;
            // 
            // menu
            // 
            menu.BackgroundImage = Properties.Resources.menu;
            menu.BackgroundImageLayout = ImageLayout.Zoom;
            menu.Cursor = Cursors.Hand;
            menu.FlatAppearance.BorderSize = 0;
            menu.FlatAppearance.MouseDownBackColor = Color.Transparent;
            menu.FlatAppearance.MouseOverBackColor = Color.Transparent;
            menu.FlatStyle = FlatStyle.Flat;
            menu.Location = new Point(24, 30);
            menu.Margin = new Padding(3, 2, 3, 2);
            menu.Name = "menu";
            menu.Size = new Size(59, 41);
            menu.TabIndex = 0;
            menu.UseVisualStyleBackColor = true;
            menu.Click += menu_Click;
            // 
            // barraLateral
            // 
            barraLateral.BackColor = Color.WhiteSmoke;
            barraLateral.Controls.Add(btnSeparados);
            barraLateral.Controls.Add(btnInventario);
            barraLateral.Controls.Add(label2);
            barraLateral.Controls.Add(logo2);
            barraLateral.Dock = DockStyle.Left;
            barraLateral.Location = new Point(0, 100);
            barraLateral.Margin = new Padding(3, 2, 3, 2);
            barraLateral.Name = "barraLateral";
            barraLateral.Size = new Size(295, 509);
            barraLateral.TabIndex = 1;
            barraLateral.Visible = false;
            // 
            // btnSeparados
            // 
            btnSeparados.Cursor = Cursors.Hand;
            btnSeparados.FlatAppearance.BorderSize = 0;
            btnSeparados.FlatStyle = FlatStyle.Flat;
            btnSeparados.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            btnSeparados.ForeColor = Color.FromArgb(74, 197, 199);
            btnSeparados.Location = new Point(0, 229);
            btnSeparados.Margin = new Padding(3, 2, 3, 2);
            btnSeparados.Name = "btnSeparados";
            btnSeparados.Size = new Size(295, 56);
            btnSeparados.TabIndex = 6;
            btnSeparados.Text = "SEPARADOS";
            btnSeparados.UseVisualStyleBackColor = true;
            btnSeparados.Click += btnSeparados_Click;
            // 
            // btnInventario
            // 
            btnInventario.Enabled = false;
            btnInventario.FlatAppearance.BorderSize = 0;
            btnInventario.FlatStyle = FlatStyle.Flat;
            btnInventario.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            btnInventario.ForeColor = Color.FromArgb(74, 197, 199);
            btnInventario.Location = new Point(0, 169);
            btnInventario.Margin = new Padding(3, 2, 3, 2);
            btnInventario.Name = "btnInventario";
            btnInventario.Size = new Size(295, 56);
            btnInventario.TabIndex = 5;
            btnInventario.Text = "INVENTARIO";
            btnInventario.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label2.ForeColor = Color.FromArgb(74, 197, 199);
            label2.Location = new Point(32, 460);
            label2.Name = "label2";
            label2.Size = new Size(219, 21);
            label2.TabIndex = 4;
            label2.Text = "CREACIONES VALDERRAMA";
            // 
            // logo2
            // 
            logo2.BackgroundImage = Properties.Resources.logo2;
            logo2.BackgroundImageLayout = ImageLayout.Zoom;
            logo2.FlatAppearance.BorderSize = 0;
            logo2.FlatAppearance.MouseDownBackColor = Color.Transparent;
            logo2.FlatAppearance.MouseOverBackColor = Color.Transparent;
            logo2.FlatStyle = FlatStyle.Flat;
            logo2.Location = new Point(38, 358);
            logo2.Margin = new Padding(3, 2, 3, 2);
            logo2.Name = "logo2";
            logo2.Size = new Size(213, 189);
            logo2.TabIndex = 2;
            logo2.UseVisualStyleBackColor = true;
            // 
            // tablaInvnetario
            // 
            tablaInvnetario.AllowUserToAddRows = false;
            tablaInvnetario.AllowUserToDeleteRows = false;
            tablaInvnetario.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            tablaInvnetario.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            tablaInvnetario.Location = new Point(24, 193);
            tablaInvnetario.Name = "tablaInvnetario";
            tablaInvnetario.ReadOnly = true;
            tablaInvnetario.RowTemplate.Height = 25;
            tablaInvnetario.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            tablaInvnetario.Size = new Size(737, 346);
            tablaInvnetario.TabIndex = 2;
            tablaInvnetario.CellContentClick += tablaInvnetario_CellContentClick;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(comboBox_marca);
            groupBox1.Controls.Add(marca);
            groupBox1.Controls.Add(textBox_precio);
            groupBox1.Controls.Add(precio);
            groupBox1.Controls.Add(btn_insertar);
            groupBox1.Controls.Add(btn_login);
            groupBox1.Controls.Add(comboBox_proveedor);
            groupBox1.Controls.Add(proveedor);
            groupBox1.Controls.Add(textBox_fecha);
            groupBox1.Controls.Add(fecha);
            groupBox1.Controls.Add(textBox_cantidad);
            groupBox1.Controls.Add(cantidad);
            groupBox1.Controls.Add(textBox_producto);
            groupBox1.Controls.Add(producto);
            groupBox1.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            groupBox1.Location = new Point(779, 137);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(372, 402);
            groupBox1.TabIndex = 4;
            groupBox1.TabStop = false;
            groupBox1.Text = "Insertar Datos";
            // 
            // comboBox_marca
            // 
            comboBox_marca.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            comboBox_marca.FormattingEnabled = true;
            comboBox_marca.Location = new Point(117, 286);
            comboBox_marca.Name = "comboBox_marca";
            comboBox_marca.Size = new Size(229, 33);
            comboBox_marca.TabIndex = 11;
            comboBox_marca.Text = "----------------------------------";
            // 
            // marca
            // 
            marca.AutoSize = true;
            marca.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            marca.Location = new Point(29, 294);
            marca.Name = "marca";
            marca.Size = new Size(69, 25);
            marca.TabIndex = 12;
            marca.Text = "Marca:";
            // 
            // textBox_precio
            // 
            textBox_precio.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            textBox_precio.Location = new Point(117, 191);
            textBox_precio.Multiline = true;
            textBox_precio.Name = "textBox_precio";
            textBox_precio.Size = new Size(229, 28);
            textBox_precio.TabIndex = 3;
            // 
            // precio
            // 
            precio.AutoSize = true;
            precio.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            precio.Location = new Point(29, 191);
            precio.Name = "precio";
            precio.Size = new Size(69, 25);
            precio.TabIndex = 10;
            precio.Text = "Precio:";
            // 
            // btn_insertar
            // 
            btn_insertar.BackColor = Color.FromArgb(0, 192, 192);
            btn_insertar.Cursor = Cursors.Hand;
            btn_insertar.FlatAppearance.BorderSize = 0;
            btn_insertar.FlatStyle = FlatStyle.Flat;
            btn_insertar.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btn_insertar.ForeColor = Color.White;
            btn_insertar.Location = new Point(105, 344);
            btn_insertar.Margin = new Padding(3, 2, 3, 2);
            btn_insertar.Name = "btn_insertar";
            btn_insertar.Size = new Size(102, 35);
            btn_insertar.TabIndex = 9;
            btn_insertar.Text = "Insertar";
            btn_insertar.UseVisualStyleBackColor = false;
            // 
            // btn_login
            // 
            btn_login.BackColor = Color.FromArgb(192, 0, 0);
            btn_login.Cursor = Cursors.Hand;
            btn_login.FlatAppearance.BorderSize = 0;
            btn_login.FlatStyle = FlatStyle.Flat;
            btn_login.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btn_login.ForeColor = Color.White;
            btn_login.Location = new Point(232, 344);
            btn_login.Margin = new Padding(3, 2, 3, 2);
            btn_login.Name = "btn_login";
            btn_login.Size = new Size(102, 35);
            btn_login.TabIndex = 8;
            btn_login.Text = "Limpiar";
            btn_login.UseVisualStyleBackColor = false;
            // 
            // comboBox_proveedor
            // 
            comboBox_proveedor.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            comboBox_proveedor.FormattingEnabled = true;
            comboBox_proveedor.Location = new Point(117, 236);
            comboBox_proveedor.Name = "comboBox_proveedor";
            comboBox_proveedor.Size = new Size(229, 33);
            comboBox_proveedor.TabIndex = 4;
            comboBox_proveedor.Text = "----------------------------------";
            // 
            // proveedor
            // 
            proveedor.AutoSize = true;
            proveedor.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            proveedor.Location = new Point(8, 239);
            proveedor.Name = "proveedor";
            proveedor.Size = new Size(103, 25);
            proveedor.TabIndex = 6;
            proveedor.Text = "Proveedor:";
            // 
            // textBox_fecha
            // 
            textBox_fecha.Enabled = false;
            textBox_fecha.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            textBox_fecha.Location = new Point(117, 148);
            textBox_fecha.Multiline = true;
            textBox_fecha.Name = "textBox_fecha";
            textBox_fecha.ReadOnly = true;
            textBox_fecha.Size = new Size(229, 28);
            textBox_fecha.TabIndex = 5;
            // 
            // fecha
            // 
            fecha.AutoSize = true;
            fecha.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            fecha.Location = new Point(29, 148);
            fecha.Name = "fecha";
            fecha.Size = new Size(65, 25);
            fecha.TabIndex = 4;
            fecha.Text = "Fecha:";
            // 
            // textBox_cantidad
            // 
            textBox_cantidad.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            textBox_cantidad.Location = new Point(117, 100);
            textBox_cantidad.Multiline = true;
            textBox_cantidad.Name = "textBox_cantidad";
            textBox_cantidad.Size = new Size(229, 25);
            textBox_cantidad.TabIndex = 2;
            // 
            // cantidad
            // 
            cantidad.AutoSize = true;
            cantidad.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            cantidad.Location = new Point(6, 100);
            cantidad.Name = "cantidad";
            cantidad.Size = new Size(92, 25);
            cantidad.TabIndex = 2;
            cantidad.Text = "Cantidad:";
            // 
            // textBox_producto
            // 
            textBox_producto.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            textBox_producto.Location = new Point(117, 55);
            textBox_producto.Multiline = true;
            textBox_producto.Name = "textBox_producto";
            textBox_producto.Size = new Size(229, 28);
            textBox_producto.TabIndex = 1;
            // 
            // producto
            // 
            producto.AutoSize = true;
            producto.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            producto.Location = new Point(18, 55);
            producto.Name = "producto";
            producto.Size = new Size(93, 25);
            producto.TabIndex = 0;
            producto.Text = "Producto:";
            // 
            // buscar
            // 
            buscar.AutoSize = true;
            buscar.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            buscar.Location = new Point(347, 127);
            buscar.Name = "buscar";
            buscar.Size = new Size(59, 21);
            buscar.TabIndex = 15;
            buscar.Text = "Buscar:";
            buscar.Visible = false;
            // 
            // textBox_buscar
            // 
            textBox_buscar.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            textBox_buscar.ForeColor = Color.Silver;
            textBox_buscar.Location = new Point(347, 156);
            textBox_buscar.Multiline = true;
            textBox_buscar.Name = "textBox_buscar";
            textBox_buscar.Size = new Size(229, 28);
            textBox_buscar.TabIndex = 14;
            textBox_buscar.Text = "Buscar...";
            textBox_buscar.Enter += textBox_buscar_Enter;
            textBox_buscar.Leave += textBox_buscar_Leave;
            // 
            // Inventario
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(209, 238, 234);
            ClientSize = new Size(1163, 609);
            Controls.Add(buscar);
            Controls.Add(textBox_buscar);
            Controls.Add(groupBox1);
            Controls.Add(tablaInvnetario);
            Controls.Add(barraLateral);
            Controls.Add(nav);
            Margin = new Padding(3, 2, 3, 2);
            Name = "Inventario";
            Text = "Inventario";
            Load += Inventario_Load;
            nav.ResumeLayout(false);
            nav.PerformLayout();
            barraLateral.ResumeLayout(false);
            barraLateral.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)tablaInvnetario).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel nav;
        private Panel barraLateral;
        private Label label1;
        private Button logo1;
        private Button menu;
        private Button closeMenu;
        private Button logo2;
        private Label label2;
        private Button btnSeparados;
        private Button btnInventario;
        private DataGridView tablaInvnetario;
        private GroupBox groupBox1;
        private TextBox textBox_precio;
        private Label precio;
        private Button btn_insertar;
        private Button btn_login;
        private ComboBox comboBox_proveedor;
        private Label proveedor;
        private TextBox textBox_fecha;
        private Label fecha;
        private TextBox textBox_cantidad;
        private Label cantidad;
        private TextBox textBox_producto;
        private Label producto;
        private ComboBox comboBox_marca;
        private Label marca;
        private Label buscar;
        private TextBox textBox_buscar;
    }
}