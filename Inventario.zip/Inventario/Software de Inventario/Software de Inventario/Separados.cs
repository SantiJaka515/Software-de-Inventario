﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Software_de_Inventario
{
    public partial class Separados : Form
    {
        MySqlConnection conexion = new MySqlConnection("server=localhost; database=tienda; Uid=root; Pwd=;");
        public Separados()
        {
            InitializeComponent();
        }

        private void Separados_Load(object sender, EventArgs e)
        {
            timer1.Enabled = true;

            conexion.Open();

            string cadena = "SELECT separados.cliente AS Nombre, separados.descripcion AS Producto, separados.fecha AS Fecha, separados.total AS Total, proveedor.nombre AS Proveedor FROM separados INNER JOIN proveedor ON proveedor.idproveedor = separados.idproveedor";

            MySqlDataAdapter adaptador = new MySqlDataAdapter(cadena, conexion);
            DataTable dt = new DataTable();
            adaptador.Fill(dt);
            tablaSeparados.DataSource = dt;
            conexion.Close();

            conexion.Open();

            string consulta = "SELECT idproveedor, nombre FROM proveedor";
            MySqlCommand comando = new MySqlCommand(consulta, conexion);
            MySqlDataReader lector = comando.ExecuteReader();
            while (lector.Read())
            {
                comboBox.Items.Add(lector.GetString("nombre"));
                int clienteID = Convert.ToInt32(comboBox.SelectedValue);
            }
            conexion.Close();
        }

        private void btn_insertar_Click(object sender, EventArgs e)
        {
            if (textBox_cliente.Text == "" || textBox_descripcion.Text == "" || textBox_total.Text == "")
            {
                MessageBox.Show("xd");
            }
            else
            {
                conexion.Open();

                string insertSepa = "INSERT INTO separados(cliente,descripcion,fecha,total,idproveedor) VALUES (@nombre,@desc,@fec,@tot,@prov)";

                MySqlCommand comando = new MySqlCommand(insertSepa, conexion);
                comando.Parameters.AddWithValue("@nombre", textBox_cliente.Text);
                comando.Parameters.AddWithValue("@desc", textBox_descripcion.Text);
                comando.Parameters.AddWithValue("@fec", textBox_fecha.Text);
                comando.Parameters.AddWithValue("@tot", textBox_total.Text);
                comando.Parameters.AddWithValue("@prov", insertSepa);
                comando.ExecuteNonQuery();

                string cadena = "SELECT separados.cliente AS Nombre, separados.descripcion AS Producto, separados.fecha AS Fecha, separados.total AS Total, proveedor.nombre AS Proveedor FROM separados INNER JOIN proveedor ON proveedor.idproveedor = separados.idproveedor";

                MySqlDataAdapter adaptador = new MySqlDataAdapter(cadena, conexion);
                DataTable dt = new DataTable();
                adaptador.Fill(dt);
                tablaSeparados.DataSource = dt;

                MessageBox.Show("Buena");
            }
            conexion.Close();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            textBox_fecha.Text = DateTime.Now.ToShortDateString();
        }

        private void comboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void menu_Click(object sender, EventArgs e)
        {
            logo1.Visible = false;
            label1.Visible = false;
            menu.Visible = false;
            tablaSeparados.Visible = false;
            groupBox1.Visible = false;
            textBox_buscar.Visible = false;
            btn_buscar.Visible = false;

            logo2.Visible = true;
            label2.Visible = true;
            closeMenu.Visible = true;
            barraLateral.Visible = true;
        }

        private void closeMenu_Click(object sender, EventArgs e)
        {
            logo1.Visible = true;
            label1.Visible = true;
            menu.Visible = true;
            tablaSeparados.Visible = true;

            logo2.Visible = false;
            label2.Visible = false;
            closeMenu.Visible = false;
            barraLateral.Visible = false;
        }

        private void btn_buscar_Click(object sender, EventArgs e)
        {

        }

        private void textBox_buscar_TextChanged(object sender, EventArgs e)
        {
            string busqueda = textBox_buscar.Text;
            conexion.Open();
            string consulta = "SELECT separados.cliente AS Nombre, separados.descripcion AS Producto, separados.fecha AS Fecha, separados.total AS Total, proveedor.nombre AS Proveedor FROM separados INNER JOIN proveedor ON proveedor.idproveedor = separados.idproveedor WHERE separados.cliente LIKE '%" + busqueda + "%'";

            MySqlDataAdapter adaptador = new MySqlDataAdapter(consulta, conexion);
            DataTable dt = new DataTable();
            adaptador.Fill(dt);
            tablaSeparados.DataSource = dt;

            conexion.Close();

        }

        private void textBox_buscar_Enter(object sender, EventArgs e)
        {
            if (textBox_buscar.Text == "Buscar...")
            {
                textBox_buscar.Text = "";
                textBox_buscar.ForeColor = Color.Black;
                buscar.Visible = true;
            }
        }

        private void textBox_buscar_Leave(object sender, EventArgs e)
        {
            if (textBox_buscar.Text == "")
            {
                textBox_buscar.Text = "Buscar...";
                textBox_buscar.ForeColor = Color.Silver;
                buscar.Visible = false;
            }
        }

        private void comboBox_Click(object sender, EventArgs e)
        {

        }
    }
}
